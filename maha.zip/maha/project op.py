Python 3.11.9 (tags/v3.11.9:de54cf5, Apr  2 2024, 10:12:12) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

==== RESTART: C:/Users/POOJITHA/AppData/Local/Programs/Python/Python311/surekha/project.py ====
No.of colleges: 20
Name of the college: ab
List of branches: cse it iot
No.of placements: 500
Pass percentage: 60
Distance: 100
Status: autonomous
Transport: yes
Name of the college: cd
List of branches: csit aims aids
No.of placements: 600
Pass percentage: 70
Distance: 150
Status: jntuk
Transport: no
Name of the college: ef
List of branches: aids aiml mech
No.of placements: 400
Pass percentage: 60
Distance: 200
Status: autonomous
Transport: no
Name of the college: gh
List of branches: csit iot mech
No.of placements: 600
Pass percentage: 70
Distance: 250
Status: jntuk
Transport: yes
Name of the college: ij
List of branches: aids civil iot
No.of placements: 550
Pass percentage: 69
Distance: 250
Status: jntuk
Transport: no
Name of the college: kl
List of branches: cse it eee
No.of placements: 450
Pass percentage: 70
Distance: 200
Status: autonomous
Transport: no
Name of the college: mn
List of branches: aids eee civil
No.of placements: 550
Pass percentage: 69
Distance: 250
Status: jntuk
Transport: yes
Name of the college: op
List of branches: civil mech iot
No.of placements: 600
Pass percentage: 59
Distance: 300
Status: autonomous
Transport: yes
Name of the college: qr
List of branches: mech cse it
No.of placements: 600
Pass percentage: 50
Distance: 150
Status: jntuk
Transport: no
Name of the college: st
List of branches: csit iot it
No.of placements: 600
Pass percentage: 70
Distance: 150
Status: jntuk
Transport: yes
Name of the college: uv
List of branches: cse it aids
No.of placements: 470
Pass percentage: 65
Distance: 100
Status: autonomous
Transport: no
Name of the college: wx
List of branches: csit aiml aids
No.of placements: 470
Pass percentage: 65
Distance: 120
Status: jntuk
Transport: no
Name of the college: yz
List of branches: aiml aids civil
No.of placements: 650
Pass percentage: 54
Distance: 120
Status: autonomous
Transport: yes
Name of the college: pace
List of branches: cse eee mech
No.of placements: 66
Pass percentage: 77
Distance: 130
Status: jntuk
Transport: yes
Name of the college: qis
List of branches: it civil mech
No.of placements: 670
Pass percentage: 68
Distance: 130
Status: autonomous
Transport: no
Name of the college: rise
List of branches: csit civil mech
No.of placements: 660
Pass percentage: 62
Distance: 250
Status: jntuk
Transport: yes
Name of the college: zx
List of branches: csit cse iot
No.of placements: 370
Pass percentage: 78
Distance: 350
Status: autonomous
Transport: no
Name of the college: civil
List of branches: cse it iot
No.of placements: 550
Pass percentage: 79
Distance: 140
Status: jntuk
Transport: no
Name of the college: mech
List of branches: civil csit iot
No.of placements: 500
Pass percentage: 60
Distance: 200
Status: jntuk
Transport: no
Name of the college: prakasam
List of branches: civil aids aiml
No.of placements: 650
Pass percentage: 62
Distance: 250
Status: jntuk
Transport: yes
college	Branch	Placements	Percentage	Distance	Status	Transport	
{'college': 'ab', 'Branch': ['cse', 'it', 'iot'], 'Placements': 500, 'Percentage': 60.0, 'Distance': 100, 'Status': 'autonomous', 'Transport': 'yes'}
{'college': 'cd', 'Branch': ['csit', 'aims', 'aids'], 'Placements': 600, 'Percentage': 70.0, 'Distance': 150, 'Status': 'jntuk', 'Transport': 'no'}
{'college': 'ef', 'Branch': ['aids', 'aiml', 'mech'], 'Placements': 400, 'Percentage': 60.0, 'Distance': 200, 'Status': 'autonomous', 'Transport': 'no'}
{'college': 'gh', 'Branch': ['csit', 'iot', 'mech'], 'Placements': 600, 'Percentage': 70.0, 'Distance': 250, 'Status': 'jntuk', 'Transport': 'yes'}
{'college': 'ij', 'Branch': ['aids', 'civil', 'iot'], 'Placements': 550, 'Percentage': 69.0, 'Distance': 250, 'Status': 'jntuk', 'Transport': 'no'}
{'college': 'kl', 'Branch': ['cse', 'it', 'eee'], 'Placements': 450, 'Percentage': 70.0, 'Distance': 200, 'Status': 'autonomous', 'Transport': 'no'}
{'college': 'mn', 'Branch': ['aids', 'eee', 'civil'], 'Placements': 550, 'Percentage': 69.0, 'Distance': 250, 'Status': 'jntuk', 'Transport': 'yes'}
{'college': 'op', 'Branch': ['civil', 'mech', 'iot'], 'Placements': 600, 'Percentage': 59.0, 'Distance': 300, 'Status': 'autonomous', 'Transport': 'yes'}
{'college': 'qr', 'Branch': ['mech', 'cse', 'it'], 'Placements': 600, 'Percentage': 50.0, 'Distance': 150, 'Status': 'jntuk', 'Transport': 'no'}
{'college': 'st', 'Branch': ['csit', 'iot', 'it'], 'Placements': 600, 'Percentage': 70.0, 'Distance': 150, 'Status': 'jntuk', 'Transport': 'yes'}
{'college': 'uv', 'Branch': ['cse', 'it', 'aids'], 'Placements': 470, 'Percentage': 65.0, 'Distance': 100, 'Status': 'autonomous', 'Transport': 'no'}
{'college': 'wx', 'Branch': ['csit', 'aiml', 'aids'], 'Placements': 470, 'Percentage': 65.0, 'Distance': 120, 'Status': 'jntuk', 'Transport': 'no'}
{'college': 'yz', 'Branch': ['aiml', 'aids', 'civil'], 'Placements': 650, 'Percentage': 54.0, 'Distance': 120, 'Status': 'autonomous', 'Transport': 'yes'}
{'college': 'pace', 'Branch': ['cse', 'eee', 'mech'], 'Placements': 66, 'Percentage': 77.0, 'Distance': 130, 'Status': 'jntuk', 'Transport': 'yes'}
{'college': 'qis', 'Branch': ['it', 'civil', 'mech'], 'Placements': 670, 'Percentage': 68.0, 'Distance': 130, 'Status': 'autonomous', 'Transport': 'no'}
{'college': 'rise', 'Branch': ['csit', 'civil', 'mech'], 'Placements': 660, 'Percentage': 62.0, 'Distance': 250, 'Status': 'jntuk', 'Transport': 'yes'}
{'college': 'zx', 'Branch': ['csit', 'cse', 'iot'], 'Placements': 370, 'Percentage': 78.0, 'Distance': 350, 'Status': 'autonomous', 'Transport': 'no'}
{'college': 'civil', 'Branch': ['cse', 'it', 'iot'], 'Placements': 550, 'Percentage': 79.0, 'Distance': 140, 'Status': 'jntuk', 'Transport': 'no'}
{'college': 'mech', 'Branch': ['civil', 'csit', 'iot'], 'Placements': 500, 'Percentage': 60.0, 'Distance': 200, 'Status': 'jntuk', 'Transport': 'no'}
{'college': 'prakasam', 'Branch': ['civil', 'aids', 'aiml'], 'Placements': 650, 'Percentage': 62.0, 'Distance': 250, 'Status': 'jntuk', 'Transport': 'yes'}
     college               Branch  Placements  ...  Distance      Status Transport
0         ab       [cse, it, iot]         500  ...       100  autonomous       yes
1         cd   [csit, aims, aids]         600  ...       150       jntuk        no
2         ef   [aids, aiml, mech]         400  ...       200  autonomous        no
3         gh    [csit, iot, mech]         600  ...       250       jntuk       yes
4         ij   [aids, civil, iot]         550  ...       250       jntuk        no
5         kl       [cse, it, eee]         450  ...       200  autonomous        no
6         mn   [aids, eee, civil]         550  ...       250       jntuk       yes
7         op   [civil, mech, iot]         600  ...       300  autonomous       yes
8         qr      [mech, cse, it]         600  ...       150       jntuk        no
9         st      [csit, iot, it]         600  ...       150       jntuk       yes
10        uv      [cse, it, aids]         470  ...       100  autonomous        no
11        wx   [csit, aiml, aids]         470  ...       120       jntuk        no
12        yz  [aiml, aids, civil]         650  ...       120  autonomous       yes
13      pace     [cse, eee, mech]          66  ...       130       jntuk       yes
14       qis    [it, civil, mech]         670  ...       130  autonomous        no
15      rise  [csit, civil, mech]         660  ...       250       jntuk       yes
16        zx     [csit, cse, iot]         370  ...       350  autonomous        no
17     civil       [cse, it, iot]         550  ...       140       jntuk        no
18      mech   [civil, csit, iot]         500  ...       200       jntuk        no
19  prakasam  [civil, aids, aiml]         650  ...       250       jntuk       yes

[20 rows x 7 columns]
